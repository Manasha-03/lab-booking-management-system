# 🏛️ Lab & Classroom Allocation Management System
**Spring Boot 3.2 · SQLite · REST API · Maven · Vanilla HTML SPA**

---

## 🚀 How to Run

```bash
cd college-system
mvn clean package -DskipTests
java -jar target/college-system-1.0.0.jar
```

Open **http://localhost:8080** in your browser.

**Default Admin:** `admin` / `123`

---

## 👥 Role Summary

| Role | Can Do |
|------|--------|
| **Admin** | College settings, global breaks, dept timing, college halls, view system, approve bookings, search/reset |
| **Office Assistant** | View today's schedule, upcoming events, manage own dept's rooms (classrooms/labs/seminar halls). ❌ Cannot change timings |
| **Staff** | Same-day booking, advance booking (Placement/Workshop/NPTEL/Exam), view upcoming events, booking history |

---

## 📋 Booking Priority System

| Type | Priority | Advance Window | Notes |
|------|----------|----------------|-------|
| 🔴 **PLACEMENT** | Highest (1) | Up to 7 days | Overrides all lower |
| 🟠 **WORKSHOP** | High (2) | Up to 7 days | Overrides NPTEL & EXAM |
| 🔴 **EXAM** | Medium (3) | Up to 3 days | ⚠️ Requires Admin approval |
| 🔵 **NPTEL** | Low (4) | Up to 7 days | Base special priority |
| ⚪ **REGULAR** | Lowest (5) | Same-day only | Booking window must be open |

**Override Rule:** A higher-priority booking can replace a lower-priority one. The displaced booking is auto-cancelled with a note.

---

## 🏗️ Architecture

```
college-system/
├── pom.xml                                    ← Maven (Spring Boot 3.2, SQLite, JPA, Lombok)
├── src/main/
│   ├── resources/
│   │   ├── application.properties             ← SQLite config
│   │   └── static/index.html                 ← Full SPA (HTML + CSS + JS, Chart.js)
│   └── java/com/college/
│       ├── entity/         College, Department, Period, Room, AppUser, Booking
│       ├── repository/     6 JPA repositories with custom JPQL
│       ├── service/        CollegeService, DepartmentService, BookingService, AuthService
│       ├── controller/     AdminController, OfficeController, StaffController, AuthController
│       ├── dto/            Dto.java (all DTOs), SystemViewRes
│       ├── exception/      CollegeException, ResourceNotFoundException, UnauthorizedException,
│       │                   GlobalExceptionHandler (@RestControllerAdvice)
│       └── config/         TimeUtil, DataInitializer
```

---

## 🗄️ Database Schema (SQLite, auto-created)

| Table | Key Columns |
|-------|-------------|
| `college` | name, start_time, close_time, morning_break, lunch_break, evening_break, minutes_per_period |
| `department` | name, configured, start_time, close_time, breaks, minutes_per_period |
| `period` | department_id, period_number, class_start/end_time, booking_start/end_time |
| `room` | department_id (null=college hall), name, room_type (CLASSROOM/LAB/SEMINAR_HALL/COLLEGE_HALL), capacity |
| `app_user` | username, password, role (ADMIN/OFFICE_ASSISTANT/STAFF), department_id |
| `booking` | room_id, period_id, user_id, booking_date, booking_type, status, event_name, booking_group_id, period_count, admin_note |

---

## 🔌 REST API Reference

### Auth
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/register` | Register (OA or STAFF) |

### Admin
| Method | URL | Description |
|--------|-----|-------------|
| GET/POST | `/api/admin/college` | Get/save college settings |
| GET/POST | `/api/admin/departments` | List/add departments |
| DELETE | `/api/admin/departments/{id}` | Remove department |
| POST | `/api/admin/departments/configure` | Configure dept timing (Admin only) |
| GET/POST/DELETE | `/api/admin/halls` | Manage college halls |
| GET | `/api/admin/dashboard` | Dashboard stats + weekly chart |
| GET | `/api/admin/system` | Full system view |
| GET | `/api/admin/bookings` | All bookings |
| GET | `/api/admin/bookings/search?date=` | Search by date |
| GET | `/api/admin/bookings/pending` | Pending approvals |
| GET | `/api/admin/bookings/upcoming-special` | Upcoming Placement/Workshop/NPTEL/Exam |
| POST | `/api/admin/bookings/approve` | Approve or reject booking |
| POST | `/api/admin/bookings/reset` | Reset all bookings |

### Office Assistant
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/office/departments` | All departments |
| GET | `/api/office/departments/{id}` | Dept details |
| POST | `/api/office/departments/{id}/rooms` | Update rooms (classrooms/labs/seminar halls) |
| GET | `/api/office/bookings/today` | Today's bookings |
| GET | `/api/office/bookings/search?date=` | Search bookings |
| GET | `/api/office/bookings/upcoming` | Upcoming special events |

### Staff
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/staff/departments` | Configured departments |
| GET | `/api/staff/departments/{id}/availability?currentTime=&date=` | Regular availability |
| POST | `/api/staff/book?userId=` | Regular same-day booking |
| GET | `/api/staff/departments/{id}/advance-availability?date=` | Advance availability grid |
| POST | `/api/staff/book/advance?userId=` | Advance booking |
| GET | `/api/staff/upcoming-special` | Upcoming events |
| GET | `/api/staff/bookings/search?date=` | My booking history |

---

## 🔧 Period Schedule Logic

| Period | Class Time | Booking Window | Notes |
|--------|-----------|----------------|-------|
| P1 | 9.15–10.05 | 9.00–9.15 | Window = college open → dept start |
| P2 | 10.05–10.55 | 9.50–10.05 | 15 min before class |
| ☕ Morning Break | 10.55–11.10 | — | |
| P3 | 11.10–12.00 | 10.55–11.10 | Book during morning break |
| P4 | 12.00–12.50 | 11.45–12.00 | 15 min before class |
| 🍽️ Lunch Break | 12.50–1.50 | — | |
| P5 | 1.50–2.40 | 1.35–1.50 | 15 min before class |
| P6 | 2.40–3.30 | 2.25–2.40 | 15 min before class |
| 🌆 Evening Break | 3.30–3.45 | — | |
| P7 | 3.45–4.30 | 3.30–3.45 | Book during evening break |
| P8 | 4.30–5.15 | 4.15–4.30 | 15 min before class |

---

## ✅ All Bug Fixes Applied

| Bug | Fix |
|-----|-----|
| Only exact booking window start accepted | Any time within `[start, end]` accepted |
| 9.10 am inside 9.00–9.15 showed "College closed" | Correct range check with `isWithinWindow()` |
| Trailing-space login `"Anu "` fails | Username `.trim()` on register & login |
| OA could change dept timings | OA endpoint only allows room management |
| No priority system | Full 5-level priority with override + auto-cancel |
| Dashboard was blank | Real-time stats, Chart.js weekly bar chart, activity feed |
| No admin approval workflow | EXAM bookings → PENDING → Admin approves/rejects |
| No advance booking rules | Type-specific advance windows (7 days / 3 days) |
