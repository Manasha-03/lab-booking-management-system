package com.college.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "period")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Period {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    @Column(name = "period_number", nullable = false)
    private int periodNumber;  // 1-8

    @Column(name = "class_start_time", nullable = false)
    private String classStartTime;

    @Column(name = "class_end_time", nullable = false)
    private String classEndTime;

    @Column(name = "booking_start_time", nullable = false)
    private String bookingStartTime;

    @Column(name = "booking_end_time", nullable = false)
    private String bookingEndTime;
}
