package com.college.entity;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="college")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class College {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String name;
    @Column(name="start_time",nullable=false) private String startTime;
    @Column(name="close_time",nullable=false) private String closeTime;
    @Column(name="morning_break") private String morningBreak;
    @Column(name="lunch_break")   private String lunchBreak;
    @Column(name="evening_break") private String eveningBreak;
    @Column(name="minutes_per_period") private Integer minutesPerPeriod;
}
