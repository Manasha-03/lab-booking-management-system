package com.college.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "booking")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "period_id", nullable = false)
    private Period period;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private AppUser bookedBy;

    @Column(name = "booked_at", nullable = false)
    private String bookedAt;

    @Column(name = "booking_date", nullable = false)
    private LocalDate bookingDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_type", nullable = false)
    private BookingType bookingType;

    @Column(name = "event_name")
    private String eventName;

    @Column(name = "booking_group_id")
    private String bookingGroupId;

    @Column(name = "period_count")
    private int periodCount;

    /**
     * PENDING = awaiting admin approval, CONFIRMED = approved, CANCELLED = rejected/auto-cancelled
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    @Builder.Default
    private BookingStatus status = BookingStatus.CONFIRMED;

    @Column(name = "admin_note")
    private String adminNote;

    public enum BookingStatus { PENDING, CONFIRMED, CANCELLED }

    public enum BookingType {
        REGULAR,    // same-day only, lowest priority
        NPTEL,      // up to 7 days advance, low special priority
        EXAM,       // up to 3 days advance, medium priority
        WORKSHOP,   // up to 7 days advance, medium-high priority
        PLACEMENT;  // up to 7 days advance, highest priority

        /** Lower number = higher priority */
        public int priority() {
            return switch (this) {
                case PLACEMENT -> 1;
                case WORKSHOP  -> 2;
                case EXAM      -> 3;
                case NPTEL     -> 4;
                case REGULAR   -> 5;
            };
        }

        /** Max days in advance this type can be booked (0 = same day only) */
        public int maxAdvanceDays() {
            return switch (this) {
                case PLACEMENT, WORKSHOP, NPTEL -> 7;
                case EXAM    -> 3;
                case REGULAR -> 0;
            };
        }

        public boolean isSpecial() { return this != REGULAR; }
    }
}
