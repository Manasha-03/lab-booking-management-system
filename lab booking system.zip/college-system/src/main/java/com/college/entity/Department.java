package com.college.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "department")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name;

    @Column(name = "configured")
    private boolean configured = false;

    @Column(name = "start_time")
    private String startTime;

    @Column(name = "close_time")
    private String closeTime;

    @Column(name = "morning_break")
    private String morningBreak;

    @Column(name = "lunch_break")
    private String lunchBreak;

    @Column(name = "evening_break")
    private String eveningBreak;

    @Column(name = "minutes_per_period")
    private Integer minutesPerPeriod;
}
