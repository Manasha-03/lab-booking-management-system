package com.college.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "room")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * For CLASSROOM, LAB, SEMINAR_HALL: linked to a department (managed by OA).
     * For COLLEGE_HALL (Auditorium, Assembly Hall, Conference Hall): department is null (Admin-managed).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id")
    private Department department;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "room_type", nullable = false)
    private RoomType roomType;

    @Column(name = "capacity")
    private Integer capacity;

    public enum RoomType {
        CLASSROOM,
        LAB,
        SEMINAR_HALL,
        COLLEGE_HALL  // Auditorium, Assembly, Conference — Admin only
    }
}
