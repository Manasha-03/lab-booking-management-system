package com.college.service;
import com.college.dto.Dto;
import com.college.entity.College;
import com.college.exception.ResourceNotFoundException;
import com.college.repository.CollegeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @RequiredArgsConstructor
public class CollegeService {
    private final CollegeRepository collegeRepository;

    @Transactional
    public Dto.CollegeRes saveCollege(Dto.CollegeReq req) {
        List<College> all = collegeRepository.findAll();
        College c = all.isEmpty() ? new College() : all.get(0);
        c.setName(req.getName().trim());
        c.setStartTime(req.getStartTime().trim().toLowerCase());
        c.setCloseTime(req.getCloseTime().trim().toLowerCase());
        if (req.getMorningBreak()!=null && !req.getMorningBreak().isBlank()) c.setMorningBreak(req.getMorningBreak().trim().toLowerCase());
        if (req.getLunchBreak()!=null && !req.getLunchBreak().isBlank()) c.setLunchBreak(req.getLunchBreak().trim().toLowerCase());
        if (req.getEveningBreak()!=null && !req.getEveningBreak().isBlank()) c.setEveningBreak(req.getEveningBreak().trim().toLowerCase());
        if (req.getMinutesPerPeriod()!=null) c.setMinutesPerPeriod(req.getMinutesPerPeriod());
        return toRes(collegeRepository.save(c));
    }

    public Dto.CollegeRes getCollege() {
        return collegeRepository.findAll().stream().findFirst().map(this::toRes)
                .orElseThrow(()->new ResourceNotFoundException("College not configured yet"));
    }
    public College getCollegeEntity() {
        return collegeRepository.findAll().stream().findFirst()
                .orElseThrow(()->new ResourceNotFoundException("College not configured yet"));
    }
    private Dto.CollegeRes toRes(College c) {
        return Dto.CollegeRes.builder().id(c.getId()).name(c.getName())
                .startTime(c.getStartTime()).closeTime(c.getCloseTime())
                .morningBreak(c.getMorningBreak()).lunchBreak(c.getLunchBreak())
                .eveningBreak(c.getEveningBreak()).minutesPerPeriod(c.getMinutesPerPeriod()).build();
    }
}
