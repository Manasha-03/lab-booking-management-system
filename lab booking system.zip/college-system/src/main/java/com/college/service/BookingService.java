package com.college.service;

import com.college.config.TimeUtil;
import com.college.dto.Dto;
import com.college.entity.*;
import com.college.entity.Booking.BookingType;
import com.college.entity.Booking.BookingStatus;
import com.college.exception.CollegeException;
import com.college.exception.ResourceNotFoundException;
import com.college.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final PeriodRepository periodRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;
    private final CollegeRepository collegeRepository;

    // ── Regular same-day booking ──────────────────────────────────────────────

    public Dto.AvailabilityRes getAvailability(Long deptId, String currentTime, LocalDate date) {
        currentTime = currentTime.trim().toLowerCase();
        College college = getCollege();
        int curMin = TimeUtil.toMinutes(currentTime);

        if (curMin < TimeUtil.toMinutes(college.getStartTime()) || curMin > TimeUtil.toMinutes(college.getCloseTime()))
            return Dto.AvailabilityRes.builder().isOpenForBooking(false)
                    .message("College is closed. Hours: "+college.getStartTime()+" – "+college.getCloseTime())
                    .availableRooms(Collections.emptyList()).build();

        List<Period> periods = periodRepository.findByDepartmentIdOrderByPeriodNumber(deptId);
        Period active = null;
        for (Period p : periods) {
            if (curMin >= TimeUtil.toMinutes(p.getBookingStartTime()) && curMin <= TimeUtil.toMinutes(p.getBookingEndTime())) {
                active = p; break;
            }
        }
        if (active == null) {
            String next = periods.stream().filter(p->TimeUtil.toMinutes(p.getBookingStartTime())>curMin).findFirst()
                    .map(p->"Next: P"+p.getPeriodNumber()+" opens at "+p.getBookingStartTime()).orElse("No more windows today.");
            return Dto.AvailabilityRes.builder().isOpenForBooking(false)
                    .message("No booking window open at "+currentTime+". "+next)
                    .availableRooms(Collections.emptyList()).build();
        }
        return buildAvailRes(deptId, active, date);
    }

    private Dto.AvailabilityRes buildAvailRes(Long deptId, Period active, LocalDate date) {
        List<Room> allRooms = roomRepository.findByDepartmentId(deptId);
        Map<Long,Booking> bMap = new HashMap<>();
        bookingRepository.findByPeriodIdAndBookingDate(active.getId(),date).forEach(b->bMap.put(b.getRoom().getId(),b));
        List<Dto.RoomRes> roomList = allRooms.stream().map(r->{
            Booking b=bMap.get(r.getId());
            return Dto.RoomRes.builder().id(r.getId()).name(r.getName()).roomType(r.getRoomType().name())
                    .available(b==null).bookedBy(b!=null?b.getBookedBy().getUsername():null)
                    .bookingType(b!=null?b.getBookingType().name():null).eventName(b!=null?b.getEventName():null)
                    .priorityLabel(b!=null?priorityLabel(b.getBookingType()):null)
                    .status(b!=null?b.getStatus().name():null).build();
        }).collect(Collectors.toList());
        return Dto.AvailabilityRes.builder().periodId(active.getId()).periodNumber(active.getPeriodNumber())
                .classStartTime(active.getClassStartTime()).classEndTime(active.getClassEndTime())
                .bookingStartTime(active.getBookingStartTime()).bookingEndTime(active.getBookingEndTime())
                .availableRooms(roomList).isOpenForBooking(true)
                .message("Booking window open for Period "+active.getPeriodNumber()+" ("+active.getBookingStartTime()+" – "+active.getBookingEndTime()+")")
                .build();
    }

    @Transactional
    public Dto.BookingRes bookRoom(Long userId, Dto.BookingReq req) {
        String ct = req.getCurrentTime().trim().toLowerCase();
        LocalDate date = req.getBookingDate()!=null ? req.getBookingDate() : LocalDate.now();
        if (!date.equals(LocalDate.now()))
            throw new CollegeException("Regular booking is today only. Use Advance Booking for future dates.");

        College college = getCollege();
        int curMin = TimeUtil.toMinutes(ct);
        if (curMin<TimeUtil.toMinutes(college.getStartTime())||curMin>TimeUtil.toMinutes(college.getCloseTime()))
            throw new CollegeException("College is closed.");

        Period period = periodRepository.findById(req.getPeriodId()).orElseThrow(()->new ResourceNotFoundException("Period not found"));
        if (curMin<TimeUtil.toMinutes(period.getBookingStartTime())||curMin>TimeUtil.toMinutes(period.getBookingEndTime()))
            throw new CollegeException("Time "+ct+" is outside booking window ("+period.getBookingStartTime()+" – "+period.getBookingEndTime()+") for P"+period.getPeriodNumber());

        Room room = roomRepository.findById(req.getRoomId()).orElseThrow(()->new ResourceNotFoundException("Room not found"));
        AppUser user = userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("User not found"));

        checkConflict(room.getId(), period.getId(), date, BookingType.REGULAR);

        Booking b = Booking.builder().room(room).period(period).bookedBy(user)
                .bookedAt(ct).bookingDate(date).bookingType(BookingType.REGULAR)
                .status(BookingStatus.CONFIRMED).periodCount(1).build();
        return toRes(bookingRepository.save(b));
    }

    // ── Advance booking (Placement/Workshop/NPTEL/Exam) ───────────────────────

    public Dto.AdvanceAvailRes getAdvanceAvailability(Long deptId, LocalDate date) {
        validateAdvanceDate(date, BookingType.PLACEMENT); // use max window for preview
        List<Period> periods = periodRepository.findByDepartmentIdOrderByPeriodNumber(deptId);
        List<Room> rooms = roomRepository.findByDepartmentId(deptId);
        Map<String,Booking> key2b = new HashMap<>();
        for (Period p : periods)
            bookingRepository.findByPeriodIdAndBookingDate(p.getId(),date).forEach(b->key2b.put(b.getRoom().getId()+":"+p.getId(),b));
        List<Dto.RoomPeriodStatus> matrix = rooms.stream().map(r->{
            List<Dto.PeriodSlotStatus> slots = periods.stream().map(p->{
                Booking b=key2b.get(r.getId()+":"+p.getId());
                return Dto.PeriodSlotStatus.builder().periodId(p.getId()).periodNumber(p.getPeriodNumber())
                        .available(b==null).bookingType(b!=null?b.getBookingType().name():null)
                        .eventName(b!=null?b.getEventName():null).bookedBy(b!=null?b.getBookedBy().getUsername():null)
                        .status(b!=null?b.getStatus().name():null).build();
            }).collect(Collectors.toList());
            return Dto.RoomPeriodStatus.builder().roomId(r.getId()).roomName(r.getName()).roomType(r.getRoomType().name()).slots(slots).build();
        }).collect(Collectors.toList());
        List<Dto.PeriodRes> pres = periods.stream().map(p->Dto.PeriodRes.builder().id(p.getId()).periodNumber(p.getPeriodNumber())
                .classStartTime(p.getClassStartTime()).classEndTime(p.getClassEndTime())
                .bookingStartTime(p.getBookingStartTime()).bookingEndTime(p.getBookingEndTime()).build()).collect(Collectors.toList());
        return Dto.AdvanceAvailRes.builder().date(date).periods(pres).roomPeriodMatrix(matrix).build();
    }

    @Transactional
    public List<Dto.BookingRes> createAdvanceBooking(Long userId, Dto.AdvanceBookingReq req) {
        BookingType bType = parseType(req.getBookingType());
        if (bType==BookingType.REGULAR) throw new CollegeException("Use regular booking for REGULAR type.");
        validateAdvanceDate(req.getEventDate(), bType);

        Room room = roomRepository.findById(req.getRoomId()).orElseThrow(()->new ResourceNotFoundException("Room not found"));
        AppUser user = userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("User not found"));
        List<Period> allP = periodRepository.findByDepartmentIdOrderByPeriodNumber(req.getDeptId());
        List<Period> targets = resolvePeriods(allP, req);

        // High priority needs admin approval; EXAM always needs approval
        boolean needsApproval = (bType==BookingType.EXAM);
        BookingStatus status = needsApproval ? BookingStatus.PENDING : BookingStatus.CONFIRMED;

        String groupId = UUID.randomUUID().toString();
        List<Dto.BookingRes> results = new ArrayList<>();

        for (Period period : targets) {
            Optional<Booking> existing = bookingRepository.findByRoomIdAndPeriodIdAndBookingDate(room.getId(),period.getId(),req.getEventDate());
            if (existing.isPresent()) {
                Booking ex = existing.get();
                if (ex.getBookingType().priority()<=bType.priority())
                    throw new CollegeException("P"+period.getPeriodNumber()+": '"+room.getName()+"' already has "+ex.getBookingType()+" (equal/higher priority). Cannot override.");
                // Auto-cancel lower priority booking
                ex.setStatus(BookingStatus.CANCELLED);
                ex.setAdminNote("Auto-cancelled: overridden by "+bType+" booking ("+req.getEventName()+")");
                bookingRepository.save(ex);
            }
            Booking b = Booking.builder().room(room).period(period).bookedBy(user)
                    .bookedAt(LocalDate.now().toString()).bookingDate(req.getEventDate())
                    .bookingType(bType).eventName(req.getEventName().trim())
                    .bookingGroupId(groupId).periodCount(targets.size())
                    .status(status).build();
            results.add(toRes(bookingRepository.save(b)));
        }
        return results;
    }

    // ── Admin approval ────────────────────────────────────────────────────────

    @Transactional
    public Dto.BookingRes processApproval(Dto.ApprovalReq req) {
        Booking b = bookingRepository.findById(req.getBookingId()).orElseThrow(()->new ResourceNotFoundException("Booking not found"));
        if (b.getStatus()!=BookingStatus.PENDING) throw new CollegeException("Booking is not pending approval.");
        if ("APPROVE".equalsIgnoreCase(req.getAction())) {
            b.setStatus(BookingStatus.CONFIRMED);
            b.setAdminNote(req.getNote());
        } else if ("REJECT".equalsIgnoreCase(req.getAction())) {
            b.setStatus(BookingStatus.CANCELLED);
            b.setAdminNote(req.getNote()!=null?req.getNote():"Rejected by Admin.");
        } else throw new CollegeException("Action must be APPROVE or REJECT.");
        return toRes(bookingRepository.save(b));
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    public List<Dto.BookingRes> searchByDate(LocalDate date) {
        return bookingRepository.findByBookingDateOrderByPeriodPeriodNumber(date).stream().map(this::toRes).collect(Collectors.toList());
    }
    public List<Dto.BookingRes> getAllBookings() {
        return bookingRepository.findAll().stream().map(this::toRes).collect(Collectors.toList());
    }
    public List<Dto.BookingRes> getUpcomingSpecialBookings() {
        LocalDate today=LocalDate.now();
        return bookingRepository.findSpecialBookingsInRange(
                List.of(BookingType.PLACEMENT,BookingType.WORKSHOP,BookingType.NPTEL,BookingType.EXAM),
                today,today.plusDays(7)).stream().map(this::toRes).collect(Collectors.toList());
    }
    public List<Dto.BookingRes> getPendingBookings() {
        return bookingRepository.findByStatus(BookingStatus.PENDING).stream().map(this::toRes).collect(Collectors.toList());
    }
    public long countWeeklyBookings() {
        LocalDate today=LocalDate.now();
        return bookingRepository.countByDateRange(today.minusDays(6),today);
    }
    public long countByDate(LocalDate date) {
        return bookingRepository.findByBookingDateOrderByPeriodPeriodNumber(date).size();
    }
    @Transactional public void resetBookings() { bookingRepository.deleteAll(); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void checkConflict(Long roomId, Long periodId, LocalDate date, BookingType newType) {
        bookingRepository.findByRoomIdAndPeriodIdAndBookingDate(roomId,periodId,date).ifPresent(ex->{
            if (ex.getStatus()==BookingStatus.CANCELLED) return;
            if (ex.getBookingType().priority()<=newType.priority())
                throw new CollegeException("Room already booked by "+ex.getBookedBy().getUsername()+" ("+ex.getBookingType()+"). Cannot override.");
        });
    }

    private void validateAdvanceDate(LocalDate date, BookingType type) {
        if (!date.isAfter(LocalDate.now())) throw new CollegeException("Advance booking must be for a future date.");
        int maxDays = type.maxAdvanceDays();
        if (date.isAfter(LocalDate.now().plusDays(maxDays)))
            throw new CollegeException(type+" bookings can only be made up to "+maxDays+" days in advance.");
    }

    private BookingType parseType(String s) {
        try { return BookingType.valueOf(s.toUpperCase()); }
        catch(Exception e) { throw new CollegeException("Invalid booking type: "+s+". Use PLACEMENT, WORKSHOP, NPTEL, or EXAM."); }
    }

    private List<Period> resolvePeriods(List<Period> all, Dto.AdvanceBookingReq req) {
        if (req.getBlockSize()!=null) {
            int sz=req.getBlockSize();
            if (sz!=4&&sz!=8) throw new CollegeException("Block size must be 4 or 8.");
            if (sz==8) return new ArrayList<>(all);
            int start=req.getBlockStartPeriod()!=null?req.getBlockStartPeriod():1;
            List<Period> block=all.stream().filter(p->p.getPeriodNumber()>=start&&p.getPeriodNumber()<start+sz).collect(Collectors.toList());
            if (block.size()<sz) throw new CollegeException("Not enough periods for block of "+sz+" from P"+start+".");
            return block;
        }
        if (req.getPeriodIds()!=null && !req.getPeriodIds().isEmpty()) {
            Map<Long,Period> map=all.stream().collect(Collectors.toMap(Period::getId,p->p));
            return req.getPeriodIds().stream().map(id->Optional.ofNullable(map.get(id))
                    .orElseThrow(()->new CollegeException("Period not found: "+id))).collect(Collectors.toList());
        }
        throw new CollegeException("Provide periodIds or blockSize.");
    }

    private College getCollege() {
        return collegeRepository.findAll().stream().findFirst().orElseThrow(()->new ResourceNotFoundException("College not configured yet"));
    }

    private String priorityLabel(BookingType t) {
        return switch(t){case PLACEMENT->"🔴 HIGH";case WORKSHOP->"🟠 HIGH";case EXAM->"🟡 MEDIUM";case NPTEL->"🟢 LOW";case REGULAR->"⚪ REGULAR";};
    }

    Dto.BookingRes toRes(Booking b) {
        return Dto.BookingRes.builder().id(b.getId())
                .roomName(b.getRoom().getName()).roomType(b.getRoom().getRoomType().name())
                .periodNumber(b.getPeriod().getPeriodNumber())
                .classStartTime(b.getPeriod().getClassStartTime()).classEndTime(b.getPeriod().getClassEndTime())
                .bookedAt(b.getBookedAt()).bookingDate(b.getBookingDate())
                .bookedBy(b.getBookedBy().getUsername()).bookingType(b.getBookingType().name())
                .eventName(b.getEventName()).bookingGroupId(b.getBookingGroupId()).periodCount(b.getPeriodCount())
                .deptName(b.getPeriod().getDepartment().getName()).priorityLabel(priorityLabel(b.getBookingType()))
                .status(b.getStatus().name()).adminNote(b.getAdminNote()).build();
    }
}
