package com.college.service;

import com.college.dto.Dto;
import com.college.entity.AppUser;
import com.college.entity.Department;
import com.college.exception.CollegeException;
import com.college.exception.UnauthorizedException;
import com.college.repository.DepartmentRepository;
import com.college.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;

    private static final Pattern HAS_UPPER   = Pattern.compile("[A-Z]");
    private static final Pattern HAS_SPECIAL = Pattern.compile("[^a-zA-Z0-9]");

    @Transactional
    public Dto.UserRes register(Dto.RegisterReq req) {
        String username = req.getUsername().trim();
        if (userRepository.existsByUsername(username))
            throw new CollegeException("Username already exists: " + username);

        AppUser.UserRole role;
        try { role = AppUser.UserRole.valueOf(req.getRole().toUpperCase()); }
        catch (IllegalArgumentException e) { throw new CollegeException("Invalid role. Use OFFICE_ASSISTANT or STAFF"); }
        if (role == AppUser.UserRole.ADMIN)
            throw new CollegeException("Cannot self-register as ADMIN");

        String pwd = req.getPassword();
        if (pwd.length() < 8) throw new CollegeException("Password must be at least 8 characters");
        if (!HAS_UPPER.matcher(pwd).find()) throw new CollegeException("Password must contain at least one capital letter");
        if (!HAS_SPECIAL.matcher(pwd).find()) throw new CollegeException("Password must contain at least one special character");

        Department dept = null;
        if (role == AppUser.UserRole.OFFICE_ASSISTANT) {
            if (req.getDepartmentName() == null || req.getDepartmentName().isBlank())
                throw new CollegeException("Office Assistant must belong to a department");
            dept = departmentRepository.findByName(req.getDepartmentName().trim())
                    .orElseThrow(() -> new CollegeException("Department not found: " + req.getDepartmentName()));
        }

        AppUser user = userRepository.save(AppUser.builder()
                .username(username).password(pwd).role(role).department(dept).build());
        return toRes(user);
    }

    public Dto.UserRes login(Dto.LoginReq req) {
        String username = req.getUsername().trim();
        AppUser user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UnauthorizedException("Login Failed! Invalid username or password."));
        if (!user.getPassword().equals(req.getPassword()))
            throw new UnauthorizedException("Login Failed! Invalid username or password.");
        return toRes(user);
    }

    private Dto.UserRes toRes(AppUser u) {
        return Dto.UserRes.builder()
                .id(u.getId()).username(u.getUsername()).role(u.getRole().name())
                .department(u.getDepartment() != null ? u.getDepartment().getName() : null)
                .departmentId(u.getDepartment() != null ? u.getDepartment().getId() : null)
                .build();
    }
}
