package com.college.service;

import com.college.config.TimeUtil;
import com.college.dto.Dto;
import com.college.entity.*;
import com.college.exception.CollegeException;
import com.college.exception.ResourceNotFoundException;
import com.college.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final PeriodRepository periodRepository;
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;
    private final CollegeRepository collegeRepository;

    // ── Admin: add/remove departments ────────────────────────────────────────
    @Transactional
    public List<String> addDepartments(List<String> names) {
        List<String> added = new ArrayList<>();
        for (String name : names) {
            String t = name.trim();
            if (t.isBlank()) continue;
            if (departmentRepository.existsByName(t)) throw new CollegeException("Department already exists: "+t);
            departmentRepository.save(Department.builder().name(t).configured(false).build());
            added.add(t);
        }
        return added;
    }

    @Transactional
    public void removeDepartment(Long id) {
        Department d = departmentRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Department not found"));
        bookingRepository.deleteByPeriodDepartmentId(id);
        periodRepository.deleteByDepartmentId(id);
        roomRepository.deleteByDepartmentId(id);
        departmentRepository.delete(d);
    }

    public List<Dto.DeptRes> getAllDepartments() {
        return departmentRepository.findAll().stream().map(this::toDeptRes).collect(Collectors.toList());
    }

    public Dto.DeptRes getDepartment(Long id) {
        return toDeptRes(departmentRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Department not found")));
    }

    // ── ADMIN: Configure department timing (Admin only) ───────────────────────
    @Transactional
    public Dto.DeptRes adminConfigureDepartment(Dto.AdminDeptConfigReq req) {
        Department dept = departmentRepository.findById(req.getDeptId())
                .orElseThrow(()->new ResourceNotFoundException("Department not found"));
        College college = collegeRepository.findAll().stream().findFirst().orElse(null);

        dept.setStartTime(req.getStartTime().trim().toLowerCase());
        dept.setCloseTime(req.getCloseTime().trim().toLowerCase());

        String morn  = pickBreak(req.getMorningBreak(),  college!=null ? college.getMorningBreak()  : null);
        String lunch = pickBreak(req.getLunchBreak(),    college!=null ? college.getLunchBreak()    : null);
        String eve   = pickBreak(req.getEveningBreak(),  college!=null ? college.getEveningBreak()  : null);
        if (morn==null)  throw new CollegeException("Morning break required (set here or in College Details).");
        if (lunch==null) throw new CollegeException("Lunch break required.");
        if (eve==null)   throw new CollegeException("Evening break required.");
        dept.setMorningBreak(morn); dept.setLunchBreak(lunch); dept.setEveningBreak(eve);

        int mpp = req.getMinutesPerPeriod()!=null ? req.getMinutesPerPeriod()
                : (college!=null && college.getMinutesPerPeriod()!=null) ? college.getMinutesPerPeriod() : 50;
        dept.setMinutesPerPeriod(mpp);
        dept.setConfigured(true);
        departmentRepository.save(dept);

        // Regenerate periods (don't wipe rooms)
        bookingRepository.deleteByPeriodDepartmentId(dept.getId());
        periodRepository.deleteByDepartmentId(dept.getId());
        generatePeriods(dept, college);

        return toDeptRes(dept);
    }

    // ── OA: manage rooms only (no timing changes) ─────────────────────────────
    @Transactional
    public Dto.DeptRes oaUpdateRooms(Long deptId, Dto.OARoomsReq req) {
        Department dept = departmentRepository.findById(deptId)
                .orElseThrow(()->new ResourceNotFoundException("Department not found"));
        if (!dept.isConfigured())
            throw new CollegeException("Department timing not configured yet. Ask Admin to configure timings.");

        // Remove old dept-scoped rooms, re-add
        roomRepository.deleteByDepartmentId(deptId);

        for (String n : req.getClassrooms())  if(n!=null && !n.isBlank()) saveRoom(dept, n, Room.RoomType.CLASSROOM, null);
        for (String n : req.getLabs())         if(n!=null && !n.isBlank()) saveRoom(dept, n, Room.RoomType.LAB, null);
        for (String n : req.getSeminarHalls()) if(n!=null && !n.isBlank()) saveRoom(dept, n, Room.RoomType.SEMINAR_HALL, null);

        return toDeptRes(dept);
    }

    private void saveRoom(Department dept, String name, Room.RoomType type, Integer cap) {
        roomRepository.save(Room.builder().department(dept).name(name.trim()).roomType(type).capacity(cap).build());
    }

    // ── Admin: College Halls (Auditorium, Assembly, Conference) ──────────────
    @Transactional
    public Dto.RoomRes addCollegeHall(Dto.CollegeHallReq req) {
        Room r = Room.builder().name(req.getName().trim()).roomType(Room.RoomType.COLLEGE_HALL)
                .capacity(req.getCapacity()).build();
        r = roomRepository.save(r);
        return roomToRes(r, null);
    }

    @Transactional
    public void deleteCollegeHall(Long roomId) {
        Room r = roomRepository.findById(roomId).orElseThrow(()->new ResourceNotFoundException("Hall not found"));
        if (r.getRoomType() != Room.RoomType.COLLEGE_HALL) throw new CollegeException("Not a college hall.");
        roomRepository.delete(r);
    }

    public List<Dto.RoomRes> getCollegeHalls() {
        return roomRepository.findByDepartmentIsNull().stream()
                .filter(r->r.getRoomType()==Room.RoomType.COLLEGE_HALL)
                .map(r->roomToRes(r,null)).collect(Collectors.toList());
    }

    // ── Period generation ─────────────────────────────────────────────────────
    private void generatePeriods(Department dept, College college) {
        int mpp = dept.getMinutesPerPeriod();
        String[] mornP  = splitBreak(dept.getMorningBreak());
        String[] lunchP = splitBreak(dept.getLunchBreak());
        String[] eveP   = splitBreak(dept.getEveningBreak());

        String morningStart=mornP[0],  morningEnd=mornP[1];
        String lunchStart=lunchP[0],   lunchEnd=lunchP[1];
        String eveningStart=eveP[0],   eveningEnd=eveP[1];
        String collegeStart = (college!=null && college.getStartTime()!=null)
                ? college.getStartTime() : TimeUtil.subtractMinutes(dept.getStartTime(),15);

        List<String[]> sched = new ArrayList<>();
        String p1s=dept.getStartTime(), p1e=TimeUtil.addMinutes(p1s,mpp);
        sched.add(new String[]{p1s,p1e,collegeStart,p1s});
        String p2s=p1e, p2e=morningStart;
        sched.add(new String[]{p2s,p2e,TimeUtil.subtractMinutes(p2s,15),p2s});
        String p3s=morningEnd, p3e=TimeUtil.addMinutes(p3s,mpp);
        sched.add(new String[]{p3s,p3e,morningStart,morningEnd});
        String p4s=p3e, p4e=lunchStart;
        sched.add(new String[]{p4s,p4e,TimeUtil.subtractMinutes(p4s,15),p4s});
        String p5s=lunchEnd, p5e=TimeUtil.addMinutes(p5s,mpp);
        sched.add(new String[]{p5s,p5e,TimeUtil.subtractMinutes(p5s,15),p5s});
        String p6s=p5e, p6e=eveningStart;
        sched.add(new String[]{p6s,p6e,TimeUtil.subtractMinutes(p6s,15),p6s});
        String p7s=eveningEnd, p7e=TimeUtil.addMinutes(p7s,45);
        sched.add(new String[]{p7s,p7e,eveningStart,eveningEnd});
        String p8s=p7e, p8e=dept.getCloseTime();
        sched.add(new String[]{p8s,p8e,TimeUtil.subtractMinutes(p8s,15),p8s});

        for (int i=0; i<sched.size(); i++) {
            String[] s=sched.get(i);
            periodRepository.save(Period.builder().department(dept).periodNumber(i+1)
                    .classStartTime(s[0]).classEndTime(s[1]).bookingStartTime(s[2]).bookingEndTime(s[3]).build());
        }
    }

    private String pickBreak(String fromReq, String fromCollege) {
        if (fromReq!=null && !fromReq.isBlank()) return fromReq.trim().toLowerCase();
        if (fromCollege!=null && !fromCollege.isBlank()) return fromCollege.trim().toLowerCase();
        return null;
    }

    private String[] splitBreak(String s) {
        String[] parts = s.trim().toLowerCase().split("\\s*-\\s*(?=[0-9])");
        if (parts.length!=2) throw new CollegeException("Invalid break format: '"+s+"'. Use: HH.MM am - HH.MM pm");
        return new String[]{parts[0].trim(), parts[1].trim()};
    }

    // ── Dashboard ─────────────────────────────────────────────────────────────
    public Dto.DashboardStats getDashboardStats(BookingService bs) {
        List<Dto.DeptRes> depts = getAllDepartments();
        College college = collegeRepository.findAll().stream().findFirst().orElse(null);
        LocalDate today = LocalDate.now();

        List<Dto.BookingRes> todayBks = bs.searchByDate(today);
        List<Dto.BookingRes> upcoming = bs.getUpcomingSpecialBookings();
        List<Dto.BookingRes> pending  = bs.getPendingBookings();

        int totalRooms = depts.stream().mapToInt(d->(d.classrooms!=null?d.classrooms.size():0)+(d.labs!=null?d.labs.size():0)+(d.seminarHalls!=null?d.seminarHalls.size():0)).sum()
                + getCollegeHalls().size();

        long weeklyCount = bs.countWeeklyBookings();
        int slots = depts.stream().mapToInt(d->(d.periods!=null?d.periods.size():0)*(d.classrooms!=null?d.classrooms.size():0)+(d.labs!=null?d.labs.size():0)).sum();
        double util = slots>0 ? Math.min(100.0,(todayBks.size()*100.0/slots)) : 0;

        // Build weekly chart data
        List<Dto.WeeklyCount> chart = new ArrayList<>();
        for (int i=6;i>=0;i--) {
            LocalDate d = today.minusDays(i);
            chart.add(Dto.WeeklyCount.builder().date(d.toString()).count(bs.countByDate(d)).build());
        }

        return Dto.DashboardStats.builder()
                .totalDepts(depts.size())
                .configuredDepts((int)depts.stream().filter(Dto.DeptRes::isConfigured).count())
                .todayBookings(todayBks.size())
                .weeklyBookings((int)weeklyCount)
                .upcomingSpecialEvents(upcoming.size())
                .totalRooms(totalRooms)
                .pendingApprovals(pending.size())
                .utilizationPct(Math.round(util*10)/10.0)
                .collegeName(college!=null?college.getName():"—")
                .collegeHours(college!=null?college.getStartTime()+" – "+college.getCloseTime():"—")
                .upcomingEvents(upcoming)
                .todayBookingsList(todayBks)
                .pendingList(pending)
                .weeklyChart(chart)
                .build();
    }

    private Dto.DeptRes toDeptRes(Department d) {
        List<Period> periods = periodRepository.findByDepartmentIdOrderByPeriodNumber(d.getId());
        List<Room> rooms = roomRepository.findByDepartmentId(d.getId());
        return Dto.DeptRes.builder()
                .id(d.getId()).name(d.getName()).configured(d.isConfigured())
                .startTime(d.getStartTime()).closeTime(d.getCloseTime())
                .morningBreak(d.getMorningBreak()).lunchBreak(d.getLunchBreak()).eveningBreak(d.getEveningBreak())
                .minutesPerPeriod(d.getMinutesPerPeriod())
                .periods(periods.stream().map(p->Dto.PeriodRes.builder().id(p.getId()).periodNumber(p.getPeriodNumber())
                        .classStartTime(p.getClassStartTime()).classEndTime(p.getClassEndTime())
                        .bookingStartTime(p.getBookingStartTime()).bookingEndTime(p.getBookingEndTime()).build()).collect(Collectors.toList()))
                .classrooms(rooms.stream().filter(r->r.getRoomType()==Room.RoomType.CLASSROOM).map(r->roomToRes(r,null)).collect(Collectors.toList()))
                .labs(rooms.stream().filter(r->r.getRoomType()==Room.RoomType.LAB).map(r->roomToRes(r,null)).collect(Collectors.toList()))
                .seminarHalls(rooms.stream().filter(r->r.getRoomType()==Room.RoomType.SEMINAR_HALL).map(r->roomToRes(r,null)).collect(Collectors.toList()))
                .build();
    }

    Dto.RoomRes roomToRes(Room r, Boolean avail) {
        return Dto.RoomRes.builder().id(r.getId()).name(r.getName()).roomType(r.getRoomType().name())
                .available(avail==null || avail).capacity(r.getCapacity()).build();
    }
}
