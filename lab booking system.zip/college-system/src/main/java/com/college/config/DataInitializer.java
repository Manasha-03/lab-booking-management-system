package com.college.config;

import com.college.entity.AppUser;
import com.college.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initAdmin(UserRepository userRepository) {
        return args -> {
            if (!userRepository.existsByUsername("admin")) {
                AppUser admin = AppUser.builder()
                        .username("admin")
                        .password("123")
                        .role(AppUser.UserRole.ADMIN)
                        .build();
                userRepository.save(admin);
                System.out.println("✅ Admin user created: admin / 123");
            }
        };
    }
}
