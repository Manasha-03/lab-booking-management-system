package com.college.config;

import com.college.exception.CollegeException;

/**
 * Utility to parse/compare time strings like "9.00 am", "10.55 am", "5.15 pm".
 * Minutes are represented as total minutes from midnight.
 */
public class TimeUtil {

    /**
     * Parse "9.00 am" / "5.15 pm" -> total minutes from midnight.
     */
    public static int toMinutes(String timeStr) {
        if (timeStr == null || timeStr.isBlank()) throw new CollegeException("Invalid time: " + timeStr);
        timeStr = timeStr.trim().toLowerCase();
        boolean isPm = timeStr.endsWith("pm");
        boolean isAm = timeStr.endsWith("am");
        if (!isPm && !isAm) throw new CollegeException("Invalid time format (expected am/pm): " + timeStr);

        String timePart = timeStr.replace("am", "").replace("pm", "").trim();
        String[] parts = timePart.split("\\.");
        if (parts.length != 2) throw new CollegeException("Invalid time format: " + timeStr);

        int hour = Integer.parseInt(parts[0].trim());
        int min = Integer.parseInt(parts[1].trim());

        if (isPm && hour != 12) hour += 12;
        if (isAm && hour == 12) hour = 0;

        return hour * 60 + min;
    }

    /**
     * Add minutes to a time string and return new time string.
     */
    public static String addMinutes(String timeStr, int minutesToAdd) {
        int total = toMinutes(timeStr) + minutesToAdd;
        return fromMinutes(total);
    }

    /**
     * Subtract minutes from a time string.
     */
    public static String subtractMinutes(String timeStr, int minutesToSubtract) {
        int total = toMinutes(timeStr) - minutesToSubtract;
        return fromMinutes(total);
    }

    /**
     * Convert minutes from midnight back to "9.00 am" format.
     */
    public static String fromMinutes(int totalMinutes) {
        int hour = totalMinutes / 60;
        int min = totalMinutes % 60;
        String suffix = "am";
        if (hour >= 12) {
            suffix = "pm";
            if (hour > 12) hour -= 12;
        }
        if (hour == 0) hour = 12;
        return String.format("%d.%02d %s", hour, min, suffix);
    }

    /**
     * Check if testTime is within [windowStart, windowEnd) inclusive on both ends.
     */
    public static boolean isWithinWindow(String testTime, String windowStart, String windowEnd) {
        int test = toMinutes(testTime);
        int start = toMinutes(windowStart);
        int end = toMinutes(windowEnd);
        return test >= start && test <= end;
    }

    /**
     * Returns true if a >= b
     */
    public static boolean isAfterOrEqual(String a, String b) {
        return toMinutes(a) >= toMinutes(b);
    }

    /**
     * Returns true if a > b
     */
    public static boolean isAfter(String a, String b) {
        return toMinutes(a) > toMinutes(b);
    }

    /**
     * Returns true if a < b
     */
    public static boolean isBefore(String a, String b) {
        return toMinutes(a) < toMinutes(b);
    }
}
