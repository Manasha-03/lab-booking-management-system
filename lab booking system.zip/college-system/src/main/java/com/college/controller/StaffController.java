package com.college.controller;

import com.college.dto.Dto;
import com.college.service.BookingService;
import com.college.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController @RequestMapping("/api/staff") @RequiredArgsConstructor @CrossOrigin(origins="*")
public class StaffController {
    private final BookingService bookingService;
    private final DepartmentService departmentService;

    @GetMapping("/departments")         public ResponseEntity<Dto.ApiRes<List<Dto.DeptRes>>> getDepts(){ return ResponseEntity.ok(Dto.ApiRes.ok("Departments.",departmentService.getAllDepartments().stream().filter(Dto.DeptRes::isConfigured).toList())); }
    @GetMapping("/departments/{id}/schedule") public ResponseEntity<Dto.ApiRes<Dto.DeptRes>> schedule(@PathVariable Long id){ return ResponseEntity.ok(Dto.ApiRes.ok("Schedule.",departmentService.getDepartment(id))); }

    @GetMapping("/departments/{deptId}/availability")
    public ResponseEntity<Dto.ApiRes<Dto.AvailabilityRes>> avail(@PathVariable Long deptId, @RequestParam String currentTime,
            @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate date){
        if(date==null) date=LocalDate.now();
        Dto.AvailabilityRes res=bookingService.getAvailability(deptId,currentTime,date);
        return ResponseEntity.ok(Dto.ApiRes.ok(res.getMessage(),res)); }

    @PostMapping("/book") public ResponseEntity<Dto.ApiRes<Dto.BookingRes>> book(@RequestParam Long userId, @RequestBody Dto.BookingReq req){
        return ResponseEntity.ok(Dto.ApiRes.ok("Booked!",bookingService.bookRoom(userId,req))); }

    @GetMapping("/departments/{deptId}/advance-availability")
    public ResponseEntity<Dto.ApiRes<Dto.AdvanceAvailRes>> advAvail(@PathVariable Long deptId,
            @RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate date){
        return ResponseEntity.ok(Dto.ApiRes.ok("Advance availability.",bookingService.getAdvanceAvailability(deptId,date))); }

    @PostMapping("/book/advance") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> bookAdv(@RequestParam Long userId, @RequestBody Dto.AdvanceBookingReq req){
        List<Dto.BookingRes> bks=bookingService.createAdvanceBooking(userId,req);
        return ResponseEntity.ok(Dto.ApiRes.ok("Advance booking created for "+bks.size()+" period(s).",bks)); }

    @GetMapping("/upcoming-special") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> upcoming(){ return ResponseEntity.ok(Dto.ApiRes.ok("Upcoming.",bookingService.getUpcomingSpecialBookings())); }

    @GetMapping("/bookings/search") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> myBookings(
            @RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate date){
        return ResponseEntity.ok(Dto.ApiRes.ok("Bookings.",bookingService.searchByDate(date))); }
}
