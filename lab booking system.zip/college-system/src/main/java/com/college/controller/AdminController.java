package com.college.controller;

import com.college.dto.Dto;
import com.college.dto.SystemViewRes;
import com.college.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController @RequestMapping("/api/admin") @RequiredArgsConstructor @CrossOrigin(origins="*")
public class AdminController {
    private final CollegeService collegeService;
    private final DepartmentService departmentService;
    private final BookingService bookingService;

    // College
    @PostMapping("/college") public ResponseEntity<Dto.ApiRes<Dto.CollegeRes>> saveCollege(@RequestBody Dto.CollegeReq req){ return ResponseEntity.ok(Dto.ApiRes.ok("College saved.",collegeService.saveCollege(req))); }
    @GetMapping("/college")  public ResponseEntity<Dto.ApiRes<Dto.CollegeRes>> getCollege(){ return ResponseEntity.ok(Dto.ApiRes.ok("College.",collegeService.getCollege())); }

    // Departments
    @PostMapping("/departments") public ResponseEntity<Dto.ApiRes<List<String>>> addDepts(@RequestBody Dto.DeptNamesReq req){ return ResponseEntity.ok(Dto.ApiRes.ok("Departments added.",departmentService.addDepartments(req.getNames()))); }
    @GetMapping("/departments")  public ResponseEntity<Dto.ApiRes<List<Dto.DeptRes>>> getDepts(){ return ResponseEntity.ok(Dto.ApiRes.ok("Departments.",departmentService.getAllDepartments())); }
    @DeleteMapping("/departments/{id}") public ResponseEntity<Dto.ApiRes<Void>> removeDept(@PathVariable Long id){ departmentService.removeDepartment(id); return ResponseEntity.ok(Dto.ApiRes.ok("Removed.")); }

    // Admin-only: configure department timing
    @PostMapping("/departments/configure") public ResponseEntity<Dto.ApiRes<Dto.DeptRes>> configDept(@RequestBody Dto.AdminDeptConfigReq req){ return ResponseEntity.ok(Dto.ApiRes.ok("Dept configured.",departmentService.adminConfigureDepartment(req))); }

    // College Halls
    @PostMapping("/halls")   public ResponseEntity<Dto.ApiRes<Dto.RoomRes>> addHall(@RequestBody Dto.CollegeHallReq req){ return ResponseEntity.ok(Dto.ApiRes.ok("Hall added.",departmentService.addCollegeHall(req))); }
    @GetMapping("/halls")    public ResponseEntity<Dto.ApiRes<List<Dto.RoomRes>>> getHalls(){ return ResponseEntity.ok(Dto.ApiRes.ok("Halls.",departmentService.getCollegeHalls())); }
    @DeleteMapping("/halls/{id}") public ResponseEntity<Dto.ApiRes<Void>> delHall(@PathVariable Long id){ departmentService.deleteCollegeHall(id); return ResponseEntity.ok(Dto.ApiRes.ok("Hall deleted.")); }

    // Dashboard & System
    @GetMapping("/dashboard") public ResponseEntity<Dto.ApiRes<Dto.DashboardStats>> dashboard(){ return ResponseEntity.ok(Dto.ApiRes.ok("Dashboard.",departmentService.getDashboardStats(bookingService))); }
    @GetMapping("/system")    public ResponseEntity<Dto.ApiRes<SystemViewRes>> system(){
        SystemViewRes v=new SystemViewRes(); v.setCollege(collegeService.getCollege()); v.setDepartments(departmentService.getAllDepartments()); v.setBookings(bookingService.getAllBookings());
        return ResponseEntity.ok(Dto.ApiRes.<SystemViewRes>ok("System.",v)); }

    // Bookings
    @GetMapping("/bookings")  public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> all(){ return ResponseEntity.ok(Dto.ApiRes.ok("All bookings.",bookingService.getAllBookings())); }
    @GetMapping("/bookings/search") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> search(@RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate date){ return ResponseEntity.ok(Dto.ApiRes.ok("Bookings.",bookingService.searchByDate(date))); }
    @GetMapping("/bookings/upcoming-special") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> upcoming(){ return ResponseEntity.ok(Dto.ApiRes.ok("Upcoming.",bookingService.getUpcomingSpecialBookings())); }
    @GetMapping("/bookings/pending") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> pending(){ return ResponseEntity.ok(Dto.ApiRes.ok("Pending.",bookingService.getPendingBookings())); }
    @PostMapping("/bookings/approve") public ResponseEntity<Dto.ApiRes<Dto.BookingRes>> approve(@RequestBody Dto.ApprovalReq req){ return ResponseEntity.ok(Dto.ApiRes.ok("Done.",bookingService.processApproval(req))); }
    @PostMapping("/bookings/reset")   public ResponseEntity<Dto.ApiRes<Void>> reset(){ bookingService.resetBookings(); return ResponseEntity.ok(Dto.ApiRes.ok("Reset done.")); }
}
