package com.college.controller;

import com.college.dto.Dto;
import com.college.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<Dto.ApiRes<Dto.UserRes>> register(@RequestBody Dto.RegisterReq req) {
        Dto.UserRes user = authService.register(req);
        return ResponseEntity.ok(Dto.ApiRes.ok("Registered successfully.", user));
    }

    @PostMapping("/login")
    public ResponseEntity<Dto.ApiRes<Dto.UserRes>> login(@RequestBody Dto.LoginReq req) {
        Dto.UserRes user = authService.login(req);
        return ResponseEntity.ok(Dto.ApiRes.ok("Login Success!", user));
    }
}
