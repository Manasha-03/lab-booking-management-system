package com.college.controller;

import com.college.dto.Dto;
import com.college.service.DepartmentService;
import com.college.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * Office Assistant: view schedules, manage OWN department's rooms only.
 * OA CANNOT change timings, breaks, or minutes per period — Admin only.
 */
@RestController @RequestMapping("/api/office") @RequiredArgsConstructor @CrossOrigin(origins="*")
public class OfficeController {
    private final DepartmentService departmentService;
    private final BookingService bookingService;

    @GetMapping("/departments")       public ResponseEntity<Dto.ApiRes<List<Dto.DeptRes>>> getDepts(){ return ResponseEntity.ok(Dto.ApiRes.ok("Departments.",departmentService.getAllDepartments())); }
    @GetMapping("/departments/{id}")  public ResponseEntity<Dto.ApiRes<Dto.DeptRes>> getDept(@PathVariable Long id){ return ResponseEntity.ok(Dto.ApiRes.ok("Dept.",departmentService.getDepartment(id))); }

    // OA manages rooms (classrooms/labs/seminar halls) of their own department ONLY
    @PostMapping("/departments/{deptId}/rooms")
    public ResponseEntity<Dto.ApiRes<Dto.DeptRes>> updateRooms(@PathVariable Long deptId, @RequestBody Dto.OARoomsReq req){
        return ResponseEntity.ok(Dto.ApiRes.ok("Rooms updated.",departmentService.oaUpdateRooms(deptId,req)));
    }

    // View today's bookings and upcoming for schedule overview
    @GetMapping("/bookings/today")  public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> today(){ return ResponseEntity.ok(Dto.ApiRes.ok("Today's bookings.",bookingService.searchByDate(LocalDate.now()))); }
    @GetMapping("/bookings/search") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> search(@RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate date){ return ResponseEntity.ok(Dto.ApiRes.ok("Bookings.",bookingService.searchByDate(date))); }
    @GetMapping("/bookings/upcoming") public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> upcoming(){ return ResponseEntity.ok(Dto.ApiRes.ok("Upcoming.",bookingService.getUpcomingSpecialBookings())); }
}
