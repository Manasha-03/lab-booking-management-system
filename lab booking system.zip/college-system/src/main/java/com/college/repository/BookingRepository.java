package com.college.repository;

import com.college.entity.Booking;
import com.college.entity.Booking.BookingType;
import com.college.entity.Booking.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    Optional<Booking> findByRoomIdAndPeriodIdAndBookingDate(Long roomId, Long periodId, LocalDate date);

    List<Booking> findByRoomIdAndBookingDate(Long roomId, LocalDate date);

    List<Booking> findByPeriodIdAndBookingDate(Long periodId, LocalDate date);

    List<Booking> findByBookingDateOrderByPeriodPeriodNumber(LocalDate date);

    List<Booking> findByBookingGroupId(String groupId);

    List<Booking> findByStatus(BookingStatus status);

    @Query("SELECT b FROM Booking b WHERE b.bookingType IN :types AND b.bookingDate BETWEEN :from AND :to ORDER BY b.bookingDate, b.period.periodNumber")
    List<Booking> findSpecialBookingsInRange(
            @Param("types") List<BookingType> types,
            @Param("from") LocalDate from,
            @Param("to") LocalDate to);

    @Query("SELECT COUNT(b) FROM Booking b WHERE b.bookingDate BETWEEN :from AND :to")
    long countByDateRange(@Param("from") LocalDate from, @Param("to") LocalDate to);

    @Modifying
    @Query("DELETE FROM Booking b WHERE b.period.department.id = :deptId")
    void deleteByPeriodDepartmentId(@Param("deptId") Long deptId);
}
