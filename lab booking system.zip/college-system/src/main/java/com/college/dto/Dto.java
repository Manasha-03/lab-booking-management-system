package com.college.dto;

import com.college.entity.Booking.BookingType;
import com.college.entity.Booking.BookingStatus;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

public class Dto {

    // ── College ──────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class CollegeReq {
        @NotBlank public String name;
        @NotBlank public String startTime;
        @NotBlank public String closeTime;
        public String morningBreak;
        public String lunchBreak;
        public String eveningBreak;
        public Integer minutesPerPeriod; // global default
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class CollegeRes {
        public Long id;
        public String name;
        public String startTime;
        public String closeTime;
        public String morningBreak;
        public String lunchBreak;
        public String eveningBreak;
        public Integer minutesPerPeriod;
    }

    // ── Department ───────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class DeptNamesReq {
        @NotNull @Size(min=1) public List<String> names;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class DeptRes {
        public Long id;
        public String name;
        public boolean configured;
        public String startTime;
        public String closeTime;
        public String morningBreak;
        public String lunchBreak;
        public String eveningBreak;
        public Integer minutesPerPeriod;
        public List<PeriodRes> periods;
        public List<RoomRes> classrooms;
        public List<RoomRes> labs;
        public List<RoomRes> seminarHalls;
    }

    // ── Admin: configure a department (Admin only) ───────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class AdminDeptConfigReq {
        @NotNull  public Long deptId;
        @NotBlank public String startTime;
        @NotBlank public String closeTime;
        public String morningBreak;   // blank → use college global
        public String lunchBreak;
        public String eveningBreak;
        public Integer minutesPerPeriod; // blank → use college global
    }

    // ── OA: manage rooms only (no timing) ────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class OARoomsReq {
        @NotNull @Size(min=0) public List<String> classrooms;
        @NotNull @Size(min=0) public List<String> labs;
        @NotNull @Size(min=0) public List<String> seminarHalls;
    }

    // ── Period ───────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PeriodRes {
        public Long id;
        public int periodNumber;
        public String classStartTime;
        public String classEndTime;
        public String bookingStartTime;
        public String bookingEndTime;
    }

    // ── Room ─────────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class RoomRes {
        public Long id;
        public String name;
        public String roomType;
        public boolean available;
        public String bookedBy;
        public String bookingType;
        public String eventName;
        public String priorityLabel;
        public String status;
        public Integer capacity;
    }

    // ── College Hall (Admin only) ─────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class CollegeHallReq {
        @NotBlank public String name;
        public Integer capacity;
    }

    // ── Auth ─────────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class RegisterReq {
        @NotBlank public String username;
        @NotBlank public String password;
        public String departmentName;
        @NotBlank public String role;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class LoginReq {
        @NotBlank public String username;
        @NotBlank public String password;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class UserRes {
        public Long id;
        public String username;
        public String role;
        public String department;
        public Long departmentId;
    }

    // ── Regular same-day booking ─────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class BookingReq {
        @NotNull  public Long roomId;
        @NotNull  public Long periodId;
        @NotBlank public String currentTime;
        public LocalDate bookingDate;
    }

    // ── Advance booking ───────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class AdvanceBookingReq {
        @NotNull  public Long deptId;
        @NotNull  public Long roomId;
        @NotBlank public String bookingType;   // PLACEMENT|WORKSHOP|NPTEL|EXAM
        @NotBlank public String eventName;
        @NotNull  public LocalDate eventDate;
        public List<Long> periodIds;           // specific periods
        public Integer blockSize;              // 4 or 8
        public Integer blockStartPeriod;       // 1-based start (for blockSize=4)
    }

    // ── Booking Response ──────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class BookingRes {
        public Long id;
        public String roomName;
        public String roomType;
        public int periodNumber;
        public String classStartTime;
        public String classEndTime;
        public String bookedAt;
        public LocalDate bookingDate;
        public String bookedBy;
        public String bookingType;
        public String eventName;
        public String bookingGroupId;
        public int periodCount;
        public String deptName;
        public String priorityLabel;
        public String status;
        public String adminNote;
    }

    // ── Availability Response ─────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class AvailabilityRes {
        public Long periodId;
        public int periodNumber;
        public String classStartTime;
        public String classEndTime;
        public String bookingStartTime;
        public String bookingEndTime;
        public List<RoomRes> availableRooms;
        public boolean isOpenForBooking;
        public String message;
    }

    // ── Advance Availability Matrix ───────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class AdvanceAvailRes {
        public LocalDate date;
        public List<PeriodRes> periods;
        public List<RoomPeriodStatus> roomPeriodMatrix;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class RoomPeriodStatus {
        public Long roomId;
        public String roomName;
        public String roomType;
        public List<PeriodSlotStatus> slots;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PeriodSlotStatus {
        public Long periodId;
        public int periodNumber;
        public boolean available;
        public String bookingType;
        public String eventName;
        public String bookedBy;
        public String status;
    }

    // ── Admin Approval ────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class ApprovalReq {
        @NotNull  public Long bookingId;
        @NotBlank public String action;   // APPROVE | REJECT
        public String note;
    }

    // ── Dashboard Stats ───────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class DashboardStats {
        public int totalDepts;
        public int configuredDepts;
        public int todayBookings;
        public int weeklyBookings;
        public int upcomingSpecialEvents;
        public int totalRooms;
        public int pendingApprovals;
        public double utilizationPct;
        public String collegeName;
        public String collegeHours;
        public List<BookingRes> upcomingEvents;
        public List<BookingRes> todayBookingsList;
        public List<BookingRes> pendingList;
        public List<WeeklyCount> weeklyChart;  // for chart
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class WeeklyCount {
        public String date;
        public long count;
    }

    // ── Generic API Response ──────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ApiRes<T> {
        public boolean success;
        public String message;
        public T data;
        public static <T> ApiRes<T> ok(String msg, T data) {
            return ApiRes.<T>builder().success(true).message(msg).data(data).build();
        }
        public static <T> ApiRes<T> ok(String msg) {
            return ApiRes.<T>builder().success(true).message(msg).build();
        }
        public static <T> ApiRes<T> fail(String msg) {
            return ApiRes.<T>builder().success(false).message(msg).build();
        }
    }
}
