package com.college.dto;

import lombok.*;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SystemViewRes {
    private Dto.CollegeRes college;
    private List<Dto.DeptRes> departments;
    private List<Dto.BookingRes> bookings;
}
